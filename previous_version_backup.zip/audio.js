// Guitar Sound Engine using Web Audio API
// Synthesizes authentic plucked guitar string tones using physical modeling principles.

class GuitarAudioEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.isMuted = false;
    this.isPlayingSequence = false;
    this.sequenceTimer = null;
  }

  init() {
    if (this.ctx) return;
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AudioContext();

    // Master volume
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(0.7, this.ctx.currentTime);

    // Warm body resonance filter (simulates guitar body cabinet)
    this.bodyFilter = this.ctx.createBiquadFilter();
    this.bodyFilter.type = 'peaking';
    this.bodyFilter.frequency.setValueAtTime(180, this.ctx.currentTime);
    this.bodyFilter.Q.setValueAtTime(1.2, this.ctx.currentTime);
    this.bodyFilter.gain.setValueAtTime(4.0, this.ctx.currentTime);

    this.highDamp = this.ctx.createBiquadFilter();
    this.highDamp.type = 'lowpass';
    this.highDamp.frequency.setValueAtTime(6500, this.ctx.currentTime);

    this.masterGain.connect(this.bodyFilter);
    this.bodyFilter.connect(this.highDamp);
    this.highDamp.connect(this.ctx.destination);
  }

  ensureContext() {
    if (!this.ctx) {
      this.init();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  midiToFrequency(midi) {
    return 440 * Math.pow(2, (midi - 69) / 12);
  }

  /**
   * Synthesize an authentic plucked guitar note
   */
  playNote(midi, duration = 1.8, velocity = 0.8) {
    if (this.isMuted) return;
    this.ensureContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const freq = this.midiToFrequency(midi);

    // 1. Fundamental & harmonic oscillators (plucked string model)
    const voiceGain = this.ctx.createGain();
    voiceGain.gain.setValueAtTime(0.001, now);
    // Instant attack for pick strike
    voiceGain.gain.exponentialRampToValueAtTime(velocity * 0.9, now + 0.006);
    // Exponential decay natural string ring
    voiceGain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    // Filter that sweeps down (strings lose high harmonics first as they ring out)
    const toneFilter = this.ctx.createBiquadFilter();
    toneFilter.type = 'lowpass';
    const startFilterFreq = Math.min(10000, freq * 14);
    const endFilterFreq = Math.min(2500, freq * 2.5);
    toneFilter.frequency.setValueAtTime(startFilterFreq, now);
    toneFilter.frequency.exponentialRampToValueAtTime(endFilterFreq, now + duration * 0.6);

    // Main fundamental tone (sawtooth gives rich guitar harmonics)
    const osc1 = this.ctx.createOscillator();
    osc1.type = 'sawtooth';
    osc1.frequency.setValueAtTime(freq, now);

    // Slight sub/second harmonic for body thickness
    const osc2 = this.ctx.createOscillator();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(freq * 2, now);

    const osc2Gain = this.ctx.createGain();
    osc2Gain.gain.setValueAtTime(0.25, now);
    osc2Gain.gain.exponentialRampToValueAtTime(0.001, now + duration * 0.5);

    // Pick attack noise transient
    const noiseBuffer = this.ctx.createBuffer(1, Math.floor(this.ctx.sampleRate * 0.035), this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < noiseBuffer.length; i++) {
      output[i] = (Math.random() * 2 - 1) * Math.exp(-i / (this.ctx.sampleRate * 0.007));
    }
    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.setValueAtTime(Math.min(3500, freq * 4), now);
    noiseFilter.Q.setValueAtTime(2.0, now);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(velocity * 0.4, now);

    // Routing
    osc1.connect(toneFilter);
    osc2.connect(osc2Gain);
    osc2Gain.connect(toneFilter);

    noiseSource.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(toneFilter);

    toneFilter.connect(voiceGain);
    voiceGain.connect(this.masterGain);

    // Start nodes
    osc1.start(now);
    osc2.start(now);
    noiseSource.start(now);

    // Stop nodes
    osc1.stop(now + duration + 0.1);
    osc2.stop(now + duration + 0.1);
    noiseSource.stop(now + 0.04);
  }

  /**
   * Arpeggiates an array of notes sequentially
   */
  async playSequence(notes, speedMs = 320, onNoteHighlight = null) {
    if (this.isPlayingSequence) {
      this.stopSequence();
      return;
    }

    this.isPlayingSequence = true;
    for (let i = 0; i < notes.length; i++) {
      if (!this.isPlayingSequence) break;
      const note = notes[i];
      if (onNoteHighlight) onNoteHighlight(note, i);
      this.playNote(note.midi, 1.2, 0.85);
      await new Promise(resolve => {
        this.sequenceTimer = setTimeout(resolve, speedMs);
      });
    }

    if (onNoteHighlight) onNoteHighlight(null, -1);
    this.isPlayingSequence = false;
  }

  stopSequence() {
    this.isPlayingSequence = false;
    if (this.sequenceTimer) {
      clearTimeout(this.sequenceTimer);
      this.sequenceTimer = null;
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }
}

export const guitarAudio = new GuitarAudioEngine();
