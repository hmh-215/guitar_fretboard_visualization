# 🎸 Guitar Fretboard & 4-5 Fret Box Position Visualizer

An interactive guitar neck visualizer designed to learn and memorize **box shapes surrounding 4–5 frets** across the fretboard for any chosen root note and mode (Major / Ionian, Minor / Aeolian, Minor Pentatonic, and Major Pentatonic).

![4-5 Fret Box Diagram Preview](preview_box_diagram.png)

---

## 🌟 Key Features

### 1. Dedicated 4–5 Fret Box Position Diagram (Matching Educational Box Charts)
- **Isolated 4 to 5 Frets Only**:
  - Focuses on the exact localized box shape without visual clutter from the rest of the neck.
  - Labels: **1st String (thinnest)** on top down to **6th String (thickest)** on bottom.
  - **Start Fret Marker (`✱`)**: Clearly denotes which fret to anchor your index finger on.
  - **Fret Number Headers**: Displays the exact physical frets (e.g. `Fret 5`, `Fret 6`, `Fret 7`, `Fret 8`).
  - **Root Notes**: Distinct highlighted circles marking the key's tonal center.
  - **Classic Print Look Toggle**: Switch with one click between dark studio theme and the classic black-and-white instructional diagram format!

### 2. Full Mode & Pentatonic Calculation
- **Minor Pentatonic (5 Notes)**:
  - Exact 1:1 match with standard guitar method box positions (e.g. Box 1 on frets 5–8 for A Minor).
- **Major Pentatonic (5 Notes)**
- **Ionian Mode (Full 7-Note Major Scale)**
- **Aeolian Mode (Full 7-Note Natural Minor Scale)**
- Choose any root note (`C`, `C#`, `D`, `D#`, `E`, `F`, `F#`, `G`, `G#`, `A`, `A#`, `B`).

### 3. Interactive Box Navigation & "Draw Box" on Neck
- **Slide the Box**:
  - Click `◀` and `▶` stepper buttons or press your keyboard's **Left/Right Arrow keys (`←` `→`)** to slide the box position up and down the neck in real time.
- **CAGED Box Selectors**:
  - 1-click jump between **Box 1 (E-Shape)**, **Box 2 (D-Shape)**, **Box 3 (C-Shape)**, **Box 4 (A-Shape)**, and **Box 5 (G-Shape)**.
- **Click to Place / Draw on Full Neck**:
  - Click on any fret of the 22-fret neck to instantly snap the 4–5 fret box to that position!

### 4. Flexible View Modes
- **🔲 Box Diagram (4–5 Frets)**: Large, focused diagram of the active box shape.
- **⚏ Split View**: Shows both the 4–5 fret box diagram AND where it sits on the 22-fret guitar neck.
- **🎸 Full Neck (22 Frets)**: Full neck view with the surrounding box boundary highlight.

### 5. Plucked Audio Synthesis (Web Audio API)
- Click any note dot on the box diagram or fretboard to hear its authentic plucked guitar tone.
- **▶ Play Box**: Arpeggiates the notes of the 4–5 fret box in sequence.

---

## 🚀 How to Run Locally

Start a local server with Python:

```powershell
python -m http.server 3000
```

Open your browser at:
```
http://localhost:3000
```

### URL Query Presets
- **A Minor Pentatonic Box 1**: `http://localhost:3000/?root=A&mode=aeolian&type=pentatonic&shape=box1`
- **Classic Print Diagram Look**: `http://localhost:3000/?root=A&mode=aeolian&theme=print`
- **C Major Pentatonic Box 1**: `http://localhost:3000/?root=C&mode=ionian&type=pentatonic&shape=box1`
- **Split View (Box + Full Neck)**: `http://localhost:3000/?view=split`
- **Full Diatonic Minor (7 Notes)**: `http://localhost:3000/?root=A&mode=aeolian&type=full`
