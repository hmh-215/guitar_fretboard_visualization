// Main Application Logic - Guitar Fretboard & 4-5 Fret Box Visualizer
import { 
  ROOT_OPTIONS, 
  SCALE_MODES, 
  CHORD_TYPES,
  TUNINGS, 
  getScaleData, 
  getChordData,
  getBoxPositions, 
  getFretNote,
  get4to5FretBoxData
} from './theory.js';
import { guitarAudio } from './audio.js';

// Application State
const state = {
  viewType: 'scale',       // 'scale' or 'chord'
  scaleType: 'pentatonic', // 'pentatonic' (5 notes) or 'full' (7 notes)
  viewMode: 'box',         // 'box' (4-5 fret diagram), 'split', or 'neck' (22 frets)
  rootNote: 'A',           // Default to A Minor Pentatonic Box 1 (exact match to uploaded image!)
  modeId: 'aeolian',       // Default to Aeolian / Minor
  activeShape: 'box1',     // Default to Box 1
  customBoxStartFret: null,// If user clicked/dragged on neck to set custom position
  labelMode: 'name',       // 'name', 'degree', 'octave', 'none'
  boxFilter: 'dim',        // 'dim', 'hide', 'normal'
  tuningId: 'standard',
  filteredNoteSemi: null,
  isMuted: false,
  isPlayingScale: false,
  isPrintLook: false,
  trainerActive: false,
  quizTargetNote: null,
  quizTargetFret: null,
  quizTargetString: null,
  quizScore: 0,
  quizTotal: 0,
  quizStreak: 0,
};

// Cached DOM Elements
const elements = {
  stringsOverlay: document.getElementById('stringsOverlay'),
  tabScale: document.getElementById('tabScale'),
  tabChord: document.getElementById('tabChord'),
  rootSelect: document.getElementById('rootSelect'),
  rootDisplay: document.getElementById('rootDisplay'),
  modeSelect: document.getElementById('modeSelect'),
  modeDisplay: document.getElementById('modeDisplay'),
  scaleTypeSelect: document.getElementById('scaleTypeSelect'),
  shapeSelect: document.getElementById('shapeSelect'),
  contextDisplay: document.getElementById('contextDisplay'),
  boxTabsContainer: document.getElementById('boxTabsContainer'),
  viewModeToggle: document.getElementById('viewModeToggle'),
  labelDisplayToggle: document.getElementById('labelDisplayToggle'),
  boxFilterToggle: document.getElementById('boxFilterToggle'),
  btnPlayScale: document.getElementById('btnPlayScale'),
  playIcon: document.getElementById('playIcon'),
  playText: document.getElementById('playText'),
  btnMuteSound: document.getElementById('btnMuteSound'),
  btnTrainerMode: document.getElementById('btnTrainerMode'),
  
  // Dedicated Box Diagram elements
  boxDiagramCard: document.getElementById('boxDiagramCard'),
  boxDiagramTitle: document.getElementById('boxDiagramTitle'),
  boxDiagramSubtitle: document.getElementById('boxDiagramSubtitle'),
  boxFretBadge: document.getElementById('boxFretBadge'),
  btnFretDown: document.getElementById('btnFretDown'),
  btnFretUp: document.getElementById('btnFretUp'),
  btnToggleTheme: document.getElementById('btnToggleTheme'),
  diagramGridContainer: document.getElementById('diagramGridContainer'),
  startFretLegendText: document.getElementById('startFretLegendText'),

  // Full Neck elements
  fullNeckStageWrapper: document.getElementById('fullNeckStageWrapper'),
  neckBoxSpanLabel: document.getElementById('neckBoxSpanLabel'),
  fretNumbersRow: document.getElementById('fretNumbersRow'),
  fretboardNeck: document.getElementById('fretboardNeck'),
  stringLabelsColumn: document.getElementById('stringLabelsColumn'),
  fretOpenColumn: document.getElementById('fretOpenColumn'),
  notesLayer: document.getElementById('notesLayer'),
  boxRegionHighlight: document.getElementById('boxRegionHighlight'),
  
  // Quiz & Footer
  trainerContainer: document.getElementById('trainerContainer'),
  quizPrompt: document.getElementById('quizPrompt'),
  quizScore: document.getElementById('quizScore'),
  quizTotal: document.getElementById('quizTotal'),
  quizStreak: document.getElementById('quizStreak'),
  quizOptions: document.getElementById('quizOptions'),
  btnCloseTrainer: document.getElementById('btnCloseTrainer'),
  scaleNotesPills: document.getElementById('scaleNotesPills'),
  scaleFormulaTitle: document.getElementById('scaleFormulaTitle'),
  tuningSelect: document.getElementById('tuningSelect'),
  fretTooltip: document.getElementById('fretTooltip'),
  tooltipTitle: document.getElementById('tooltipTitle'),
  tooltipDesc: document.getElementById('tooltipDesc'),
};

const INLAYS_SINGLE = [3, 5, 7, 9, 15, 17, 19, 21];
const INLAY_DOUBLE = 12;
const TOTAL_FRETS = 22;

/**
 * Initialize application
 */
function init() {
  const params = new URLSearchParams(window.location.search);
  if (params.has('root')) {
    const r = params.get('root').trim();
    if (ROOT_OPTIONS.some(opt => opt.value.toUpperCase() === r.toUpperCase())) {
      state.rootNote = r.toUpperCase();
    }
  }
  if (params.has('mode')) {
    const m = params.get('mode').toLowerCase();
    if (SCALE_MODES[m]) state.modeId = m;
  }
  if (params.has('type')) {
    state.scaleType = params.get('type').toLowerCase() === 'full' ? 'full' : 'pentatonic';
  }
  if (params.has('shape')) {
    state.activeShape = params.get('shape').toLowerCase();
  }
  if (params.has('view')) {
    const v = params.get('view').toLowerCase();
    if (['box', 'split', 'neck'].includes(v)) state.viewMode = v;
  }
  if (params.has('fret')) {
    state.customBoxStartFret = parseInt(params.get('fret'), 10);
  }
  if (params.has('label')) {
    state.labelMode = params.get('label').toLowerCase();
  }
  if (params.has('theme') && params.get('theme') === 'print') {
    state.isPrintLook = true;
  }

  // Synchronize controls with state
  elements.rootSelect.value = state.rootNote;
  elements.modeSelect.value = state.modeId;
  elements.scaleTypeSelect.value = state.scaleType;
  elements.shapeSelect.value = state.activeShape;

  elements.viewModeToggle.querySelectorAll('.toggle-opt').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === state.viewMode);
  });

  elements.labelDisplayToggle.querySelectorAll('.toggle-opt').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.label === state.labelMode);
  });

  if (state.isPrintLook) {
    elements.boxDiagramCard.classList.add('print-look');
  }

  buildFretboardStructure();
  setupEventListeners();
  updateUI();

  if (params.has('quiz')) {
    toggleTrainerMode();
  }
}

/**
 * Build static 22-fret neck structure
 */
function buildFretboardStructure() {
  elements.fretNumbersRow.innerHTML = '';
  
  // Col 1: Tuning label spacer
  const tuneSpacer = document.createElement('div');
  tuneSpacer.className = 'fret-num-badge';
  tuneSpacer.style.opacity = '0.4';
  tuneSpacer.style.fontSize = '0.65rem';
  elements.fretNumbersRow.appendChild(tuneSpacer);

  // Col 2: Open badge
  const openBadge = document.createElement('div');
  openBadge.className = 'fret-num-badge open-badge';
  openBadge.textContent = 'Open';
  openBadge.id = 'fret-badge-0';
  elements.fretNumbersRow.appendChild(openBadge);

  // Cols 3 to 24: Frets 1 to 22
  for (let f = 1; f <= TOTAL_FRETS; f++) {
    const badge = document.createElement('div');
    badge.className = 'fret-num-badge';
    badge.id = `fret-badge-${f}`;
    badge.textContent = f;
    if (INLAYS_SINGLE.includes(f)) badge.classList.add('marker-fret');
    if (f === INLAY_DOUBLE) badge.classList.add('octave-fret');
    elements.fretNumbersRow.appendChild(badge);
  }

  updateOpenStringControls();

  // Fret cells 1 to 22
  const existingCells = elements.fretboardNeck.querySelectorAll('.fret-cell');
  existingCells.forEach(c => c.remove());

  for (let f = 1; f <= TOTAL_FRETS; f++) {
    const cell = document.createElement('div');
    cell.className = 'fret-cell';
    cell.dataset.fret = f;
    cell.id = `fret-col-${f}`;

    // Click on fret cell to move/draw 4-5 fret box starting at this fret!
    cell.style.cursor = 'pointer';
    cell.title = `Click to draw box starting at Fret ${f}`;
    cell.addEventListener('click', () => {
      state.customBoxStartFret = f;
      state.activeShape = 'custom';
      updateUI();
    });

    if (INLAYS_SINGLE.includes(f)) {
      const inlay = document.createElement('div');
      inlay.className = 'inlay-dot-single';
      cell.appendChild(inlay);
    } else if (f === INLAY_DOUBLE) {
      const d1 = document.createElement('div');
      d1.className = 'inlay-dot-double-1';
      const d2 = document.createElement('div');
      d2.className = 'inlay-dot-double-2';
      cell.appendChild(d1);
      cell.appendChild(d2);
    }

    elements.fretboardNeck.appendChild(cell);
  }
}

/**
 * Open string tuning pegs
 */
function updateOpenStringControls() {
  const tuning = TUNINGS[state.tuningId] || TUNINGS.standard;
  elements.stringLabelsColumn.innerHTML = '';

  tuning.strings.forEach((str, strIdx) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'open-string-btn';
    btn.dataset.string = strIdx;
    btn.title = `String ${strIdx + 1} (${str.name}): click to play`;
    btn.innerHTML = `
      <span class="open-switch-pill"></span>
      <span>${str.name}</span>
    `;
    btn.addEventListener('click', () => {
      guitarAudio.playNote(str.midi, 2.0, 0.9);
      btn.classList.add('active');
      setTimeout(() => btn.classList.remove('active'), 450);
    });
    elements.stringLabelsColumn.appendChild(btn);
  });
}

/**
 * Event Listeners
 */
function setupEventListeners() {
  // Scale / Chord Tabs
  elements.tabScale.addEventListener('click', () => {
    state.viewType = 'scale';
    elements.tabScale.classList.add('active');
    elements.tabChord.classList.remove('active');
    state.filteredNoteSemi = null;
    updateUI();
  });

  elements.tabChord.addEventListener('click', () => {
    state.viewType = 'chord';
    elements.tabChord.classList.add('active');
    elements.tabScale.classList.remove('active');
    state.filteredNoteSemi = null;
    updateUI();
  });

  // Root note selector
  elements.rootSelect.addEventListener('change', (e) => {
    state.rootNote = e.target.value;
    state.customBoxStartFret = null; // Recalculate box anchor for new root
    state.filteredNoteSemi = null;
    updateUI();
  });

  // Mode selector
  elements.modeSelect.addEventListener('change', (e) => {
    state.modeId = e.target.value;
    state.customBoxStartFret = null;
    state.filteredNoteSemi = null;
    updateUI();
  });

  // Scale Type selector (Pentatonic 5-note vs Full 7-note)
  elements.scaleTypeSelect.addEventListener('change', (e) => {
    state.scaleType = e.target.value;
    state.filteredNoteSemi = null;
    updateUI();
  });

  // Active shape dropdown
  elements.shapeSelect.addEventListener('change', (e) => {
    state.activeShape = e.target.value;
    state.customBoxStartFret = null;
    updateUI();
  });

  // Quick box navigator tabs
  elements.boxTabsContainer.addEventListener('click', (e) => {
    const btn = e.target.closest('.box-tab-btn');
    if (!btn) return;
    state.activeShape = btn.dataset.box;
    state.customBoxStartFret = null;
    elements.shapeSelect.value = state.activeShape;
    updateUI();
  });

  // View mode toggle (Box Diagram, Split View, Full Neck)
  elements.viewModeToggle.addEventListener('click', (e) => {
    const btn = e.target.closest('.toggle-opt');
    if (!btn) return;
    elements.viewModeToggle.querySelectorAll('.toggle-opt').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.viewMode = btn.dataset.view;
    updateViewModeDisplay();
  });

  // Display label toggle (Notes, Degrees, Octaves, None)
  elements.labelDisplayToggle.addEventListener('click', (e) => {
    const btn = e.target.closest('.toggle-opt');
    if (!btn) return;
    elements.labelDisplayToggle.querySelectorAll('.toggle-opt').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.labelMode = btn.dataset.label;
    updateUI();
  });

  // Box filter toggle for full neck
  elements.boxFilterToggle.addEventListener('click', (e) => {
    const btn = e.target.closest('.toggle-opt');
    if (!btn) return;
    elements.boxFilterToggle.querySelectorAll('.toggle-opt').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.boxFilter = btn.dataset.filter;
    renderNeckNotes();
  });

  // Fret stepper buttons (Shift box ◀ ▶)
  elements.btnFretDown.addEventListener('click', () => {
    shiftBoxFret(-1);
  });

  elements.btnFretUp.addEventListener('click', () => {
    shiftBoxFret(1);
  });

  // Toggle Print Diagram Look
  elements.btnToggleTheme.addEventListener('click', () => {
    state.isPrintLook = !state.isPrintLook;
    elements.boxDiagramCard.classList.toggle('print-look', state.isPrintLook);
    elements.btnToggleTheme.textContent = state.isPrintLook ? '🌙 Dark Studio' : '🎨 Toggle Print Look';
  });

  // Keyboard navigation: Left/Right arrow keys slide the 4-5 fret box!
  window.addEventListener('keydown', (e) => {
    if (['INPUT', 'SELECT'].includes(document.activeElement.tagName)) return;
    if (e.key === 'ArrowLeft') {
      shiftBoxFret(-1);
    } else if (e.key === 'ArrowRight') {
      shiftBoxFret(1);
    }
  });

  // Play Scale / Box Sequence Button
  elements.btnPlayScale.addEventListener('click', () => {
    togglePlayBoxSequence();
  });

  // Sound Mute Toggle
  elements.btnMuteSound.addEventListener('click', () => {
    const muted = guitarAudio.toggleMute();
    state.isMuted = muted;
    elements.btnMuteSound.innerHTML = muted ? '🔇 Muted' : '🔊 Sound FX';
    elements.btnMuteSound.style.opacity = muted ? '0.6' : '1';
  });

  // Quiz Mode button
  elements.btnTrainerMode.addEventListener('click', () => {
    toggleTrainerMode();
  });

  elements.btnCloseTrainer.addEventListener('click', () => {
    state.trainerActive = false;
    elements.trainerContainer.classList.remove('active');
    elements.btnTrainerMode.classList.remove('active');
    updateUI();
  });

  window.addEventListener('resize', () => {
    requestAnimationFrame(() => {
      renderNeckNotes();
      updateBoxHighlightOverlay();
    });
  });
}

/**
 * Shifts the box position left or right along the neck
 */
function shiftBoxFret(delta) {
  const boxData = get4to5FretBoxData(state.rootNote, state.modeId, state.scaleType, state.activeShape, state.customBoxStartFret);
  const newStart = Math.max(0, Math.min(18, boxData.startFret + delta));
  state.customBoxStartFret = newStart;
  state.activeShape = 'custom';
  updateUI();
}

/**
 * Updates view visibility based on state.viewMode
 */
function updateViewModeDisplay() {
  if (state.viewMode === 'box') {
    elements.boxDiagramCard.style.display = 'flex';
    elements.fullNeckStageWrapper.style.display = 'none';
  } else if (state.viewMode === 'neck') {
    elements.boxDiagramCard.style.display = 'none';
    elements.fullNeckStageWrapper.style.display = 'block';
  } else { // 'split'
    elements.boxDiagramCard.style.display = 'flex';
    elements.fullNeckStageWrapper.style.display = 'block';
  }
}

/**
 * Main UI Update Cycle
 */
function updateUI() {
  updateViewModeDisplay();

  const isMinor = state.modeId === 'aeolian' || state.modeId === 'dorian';
  const modeName = isMinor ? 'Minor' : 'Major';
  const scaleTypeName = state.scaleType === 'pentatonic' ? 'Pentatonic' : (state.modeId === 'aeolian' ? 'Natural Minor' : 'Ionian (Major)');

  // Header display
  elements.rootDisplay.textContent = state.rootNote;
  elements.modeDisplay.textContent = modeName;
  elements.contextDisplay.innerHTML = `
    Key: ${state.rootNote} ${modeName}<br>
    <span style="color: #60a5fa; font-size: 0.72rem;">${scaleTypeName}</span>
  `;

  // Render the Dedicated 4-5 Fret Box Diagram
  const boxData = renderBoxDiagram();

  // Update Box tabs active status
  elements.boxTabsContainer.querySelectorAll('.box-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.box === state.activeShape);
  });

  // Render Full 22-Fret Neck & Highlight
  renderNeckNotes();
  updateBoxHighlightOverlay();

  // Footer Scale Notes Strip
  const activeData = state.viewType === 'chord'
    ? getChordData(state.rootNote, state.modeId)
    : getScaleData(state.rootNote, state.scaleType === 'pentatonic' ? (isMinor ? 'pentatonic_minor' : 'pentatonic_major') : state.modeId);
  updateNotesStrip(activeData);
}

/**
 * Renders the Dedicated 4-5 Fret Box Diagram (Matching Uploaded Image)
 */
function renderBoxDiagram() {
  const boxData = get4to5FretBoxData(state.rootNote, state.modeId, state.scaleType, state.activeShape, state.customBoxStartFret);

  // Update Title & Subtitle matching the user's diagram
  const isMinor = state.modeId === 'aeolian' || state.modeId === 'dorian';
  const typeText = state.scaleType === 'pentatonic' ? 'Pentatonic' : 'Full Scale';
  const shapeName = state.activeShape === 'custom' 
    ? `Custom Position (Frets ${boxData.startFret}–${boxData.endFret})`
    : `${boxData.boxId.toUpperCase()} Shape`;

  elements.boxDiagramTitle.textContent = "How to 'read' the box positions";
  elements.boxDiagramSubtitle.textContent = `${state.rootNote} ${isMinor ? 'Minor' : 'Major'} ${typeText} • ${shapeName}`;
  elements.boxFretBadge.textContent = `Frets ${boxData.startFret} – ${boxData.endFret}`;
  elements.neckBoxSpanLabel.textContent = `Frets ${boxData.startFret} – ${boxData.endFret}`;
  elements.startFretLegendText.innerHTML = `= <strong>Start fret (Fret ${boxData.startFret})</strong>`;

  // Build Grid Container
  elements.diagramGridContainer.innerHTML = '';

  // 1. Fret Numbers Row above Box
  const fretsHeader = document.createElement('div');
  fretsHeader.className = 'box-frets-header';
  fretsHeader.style.gridTemplateColumns = `repeat(${boxData.fretSpan}, 1fr)`;

  boxData.frets.forEach((f, idx) => {
    const title = document.createElement('div');
    title.className = 'box-fret-title';
    if (idx === 0) title.classList.add('active-start');
    title.textContent = f === 0 ? 'Open' : `Fret ${f}`;
    fretsHeader.appendChild(title);
  });
  elements.diagramGridContainer.appendChild(fretsHeader);

  // 2. The Box Matrix (Vertical fret columns & horizontal strings)
  const matrix = document.createElement('div');
  matrix.className = 'box-matrix';
  matrix.style.gridTemplateColumns = `repeat(${boxData.fretSpan}, 1fr)`;

  // Fret cells
  for (let i = 0; i < boxData.fretSpan; i++) {
    const cell = document.createElement('div');
    cell.className = 'box-matrix-cell';
    matrix.appendChild(cell);
  }

  // Horizontal string lines (6 strings)
  const stringsLayer = document.createElement('div');
  stringsLayer.className = 'box-strings-layer';
  for (let s = 0; s < 6; s++) {
    const line = document.createElement('div');
    line.className = 'box-string-line';
    if (s >= 4) line.classList.add('gauge-thick');
    stringsLayer.appendChild(line);
  }
  matrix.appendChild(stringsLayer);

  // 3. Notes Layer (Dots placed on strings and frets)
  const notesLayer = document.createElement('div');
  notesLayer.className = 'box-notes-layer';

  // Compute cell coordinates
  const colWidthPct = 100 / boxData.fretSpan;
  // 6 strings spaced with padding 30px on 280px height
  const usableHeight = 280 - 60; // 220px
  const stringSpacing = usableHeight / 5;

  for (let strIdx = 0; strIdx < 6; strIdx++) {
    const stringY = 30 + strIdx * stringSpacing;

    for (let fIdx = 0; fIdx < boxData.fretSpan; fIdx++) {
      const fretNote = boxData.stringsGrid[strIdx][fIdx];
      if (!fretNote.isInScale) continue;

      const fretX = (fIdx + 0.5) * colWidthPct;

      const dot = document.createElement('div');
      dot.className = 'box-note-dot';
      dot.style.left = `${fretX}%`;
      dot.style.top = `${stringY}px`;
      dot.dataset.midi = fretNote.midi;
      dot.dataset.string = strIdx;
      dot.dataset.fret = fretNote.fret;

      if (fretNote.isRoot) {
        dot.classList.add('is-root-note');
      } else {
        dot.classList.add('is-scale-note');
        if (fretNote.role === 'modal') dot.classList.add('role-modal');
      }

      // Dot text content
      dot.textContent = getBoxNoteText(fretNote);

      // Tooltip
      dot.addEventListener('mouseenter', (e) => showTooltip(e, fretNote));
      dot.addEventListener('mouseleave', hideTooltip);

      // Play audio on click
      dot.addEventListener('click', (e) => {
        e.stopPropagation();
        playNoteWithFeedback(dot, fretNote.midi);
      });

      notesLayer.appendChild(dot);
    }
  }
  matrix.appendChild(notesLayer);
  elements.diagramGridContainer.appendChild(matrix);

  // 4. Footer row with Asterisk (*) marking Start Fret
  const footerRow = document.createElement('div');
  footerRow.className = 'box-diagram-footer-row';
  footerRow.style.gridTemplateColumns = `repeat(${boxData.fretSpan}, 1fr)`;

  for (let i = 0; i < boxData.fretSpan; i++) {
    const indCell = document.createElement('div');
    indCell.className = 'box-fret-indicator-cell';
    if (i === 0) {
      indCell.innerHTML = `<span class="star-badge" title="Start Fret: Fret ${boxData.startFret}">✱</span>`;
    }
    footerRow.appendChild(indCell);
  }
  elements.diagramGridContainer.appendChild(footerRow);

  return boxData;
}

/**
 * Returns text inside note dot based on display mode
 */
function getBoxNoteText(fretNote) {
  if (state.labelMode === 'none') return '';
  if (state.labelMode === 'degree') return fretNote.degree || '';
  if (state.labelMode === 'octave') return `${fretNote.noteName}${fretNote.octave}`;
  
  // In print look or default 'name': root shows note or 'R'
  if (state.isPrintLook && fretNote.isRoot) return 'R';
  return fretNote.noteName;
}

/**
 * Renders notes on the 22-fret guitar neck
 */
function renderNeckNotes() {
  elements.notesLayer.innerHTML = '';
  const isMinor = state.modeId === 'aeolian' || state.modeId === 'dorian';
  const effectiveMode = state.scaleType === 'pentatonic' 
    ? (isMinor ? 'pentatonic_minor' : 'pentatonic_major') 
    : state.modeId;

  const scaleData = getScaleData(state.rootNote, effectiveMode);
  const boxData = get4to5FretBoxData(state.rootNote, state.modeId, state.scaleType, state.activeShape, state.customBoxStartFret);
  const stringLines = elements.stringsOverlay.querySelectorAll('.guitar-string-line');

  for (let strIdx = 0; strIdx < 6; strIdx++) {
    const stringEl = stringLines[strIdx];
    if (!stringEl) continue;
    const noteY = stringEl.offsetTop + stringEl.offsetHeight / 2;

    for (let fret = 0; fret <= TOTAL_FRETS; fret++) {
      const fretNote = getFretNote(state.tuningId, strIdx, fret, scaleData);
      if (!fretNote || !fretNote.isInScale) continue;

      if (state.filteredNoteSemi !== null && fretNote.semitone !== state.filteredNoteSemi) {
        continue;
      }

      // Check if note is inside the 4-5 fret box
      const isInsideBox = fret >= boxData.startFret && fret <= boxData.endFret;

      let isDimmed = false;
      let isHidden = false;

      if (!isInsideBox && state.activeShape !== 'all') {
        if (state.boxFilter === 'hide') isHidden = true;
        else if (state.boxFilter === 'dim') isDimmed = true;
      }

      if (isHidden) continue;

      let noteX = 0;
      if (fret === 0) {
        noteX = elements.fretOpenColumn.offsetLeft + elements.fretOpenColumn.offsetWidth / 2;
      } else {
        const col = document.getElementById(`fret-col-${fret}`);
        if (!col) continue;
        noteX = col.offsetLeft + col.offsetWidth / 2;
      }

      const dot = document.createElement('div');
      dot.className = `note-dot role-${fretNote.role}`;
      dot.id = `neck-dot-${strIdx}-${fret}`;
      dot.style.left = `${noteX}px`;
      dot.style.top = `${noteY}px`;
      dot.dataset.midi = fretNote.midi;

      if (isDimmed) dot.classList.add('dimmed');
      dot.textContent = getBoxNoteText(fretNote);

      dot.addEventListener('mouseenter', (e) => showTooltip(e, fretNote));
      dot.addEventListener('mouseleave', hideTooltip);
      dot.addEventListener('click', (e) => {
        e.stopPropagation();
        playNoteWithFeedback(dot, fretNote.midi);
      });

      elements.notesLayer.appendChild(dot);
    }
  }
}

/**
 * Draws the surrounding box highlight frame on the 22-fret neck
 */
function updateBoxHighlightOverlay() {
  if (state.activeShape === 'all') {
    elements.boxRegionHighlight.style.display = 'none';
    return;
  }

  const boxData = get4to5FretBoxData(state.rootNote, state.modeId, state.scaleType, state.activeShape, state.customBoxStartFret);
  const startCol = boxData.startFret === 0 
    ? elements.fretOpenColumn 
    : document.getElementById(`fret-col-${boxData.startFret}`);
  const endCol = document.getElementById(`fret-col-${boxData.endFret}`);

  if (!startCol || !endCol) {
    elements.boxRegionHighlight.style.display = 'none';
    return;
  }

  const left = startCol.offsetLeft;
  const width = (endCol.offsetLeft + endCol.offsetWidth) - left;

  elements.boxRegionHighlight.style.display = 'block';
  elements.boxRegionHighlight.style.left = `${left}px`;
  elements.boxRegionHighlight.style.width = `${width}px`;
}

/**
 * Footer Notes Strip
 */
function updateNotesStrip(activeData) {
  const isMinor = state.modeId === 'aeolian' || state.modeId === 'dorian';
  const typeText = state.scaleType === 'pentatonic' ? 'Pentatonic' : 'Full Scale';
  elements.scaleFormulaTitle.textContent = `Notes in ${state.rootNote} ${isMinor ? 'Minor' : 'Major'} ${typeText}`;
  elements.scaleNotesPills.innerHTML = '';

  activeData.notes.forEach(note => {
    const chip = document.createElement('div');
    chip.className = `scale-note-chip chip-${note.role}`;
    if (state.filteredNoteSemi === note.semitone) {
      chip.style.outline = '2px solid #ffffff';
      chip.style.transform = 'scale(1.08)';
    }

    chip.innerHTML = `
      <span class="chip-name">${note.name}</span>
      <span class="chip-degree">${note.degree} (${note.degreeName})</span>
    `;

    chip.addEventListener('click', () => {
      if (state.filteredNoteSemi === note.semitone) {
        state.filteredNoteSemi = null;
      } else {
        state.filteredNoteSemi = note.semitone;
      }
      guitarAudio.playNote(60 + note.semitone, 1.2, 0.8);
      updateUI();
    });

    elements.scaleNotesPills.appendChild(chip);
  });
}

/**
 * Arpeggiate notes inside the 4-5 fret box sequentially
 */
async function togglePlayBoxSequence() {
  if (state.isPlayingScale) {
    guitarAudio.stopSequence();
    state.isPlayingScale = false;
    elements.playIcon.textContent = '▶';
    elements.playText.textContent = 'Play Box';
    elements.btnPlayScale.classList.remove('playing');
    return;
  }

  // Find all visible dots in box diagram or full neck
  const targetDots = elements.boxDiagramCard.style.display !== 'none'
    ? Array.from(elements.diagramGridContainer.querySelectorAll('.box-note-dot'))
    : Array.from(elements.notesLayer.querySelectorAll('.note-dot:not(.dimmed)'));

  if (targetDots.length === 0) return;

  const noteList = targetDots.map(d => ({
    element: d,
    midi: parseInt(d.dataset.midi, 10),
  })).sort((a, b) => a.midi - b.midi);

  state.isPlayingScale = true;
  elements.playIcon.textContent = '⏹';
  elements.playText.textContent = 'Stop';
  elements.btnPlayScale.classList.add('playing');

  await guitarAudio.playSequence(noteList, 250, (note) => {
    if (note && note.element) {
      note.element.classList.add('playing-pulse');
      setTimeout(() => note.element.classList.remove('playing-pulse'), 350);
    }
  });

  state.isPlayingScale = false;
  elements.playIcon.textContent = '▶';
  elements.playText.textContent = 'Play Box';
  elements.btnPlayScale.classList.remove('playing');
}

function playNoteWithFeedback(dotElement, midi) {
  guitarAudio.playNote(midi, 1.8, 0.9);
  if (dotElement) {
    dotElement.classList.add('playing-pulse');
    setTimeout(() => dotElement.classList.remove('playing-pulse'), 450);
  }
}

function showTooltip(e, fretNote) {
  const freq = (440 * Math.pow(2, (fretNote.midi - 69) / 12)).toFixed(1);
  elements.tooltipTitle.textContent = `${fretNote.noteName}${fretNote.octave} (${freq} Hz)`;
  elements.tooltipDesc.textContent = `${fretNote.degreeName || 'Scale note'} • String ${fretNote.stringIndex + 1} (${fretNote.stringName}) • Fret ${fretNote.fret === 0 ? 'Open' : fretNote.fret}`;

  const dotRect = e.target.getBoundingClientRect();
  elements.fretTooltip.style.left = `${dotRect.left + dotRect.width / 2}px`;
  elements.fretTooltip.style.top = `${dotRect.top - 8}px`;
  elements.fretTooltip.style.display = 'flex';
}

function hideTooltip() {
  elements.fretTooltip.style.display = 'none';
}

/**
 * Practice Quiz
 */
function toggleTrainerMode() {
  state.trainerActive = !state.trainerActive;
  elements.trainerContainer.classList.toggle('active', state.trainerActive);
  elements.btnTrainerMode.classList.toggle('active', state.trainerActive);

  if (state.trainerActive) {
    state.quizScore = 0;
    state.quizTotal = 0;
    state.quizStreak = 0;
    updateQuizStats();
    nextQuizQuestion();
  } else {
    updateUI();
  }
}

function updateQuizStats() {
  elements.quizScore.textContent = state.quizScore;
  elements.quizTotal.textContent = state.quizTotal;
  elements.quizStreak.textContent = `${state.quizStreak} 🔥`;
}

function nextQuizQuestion() {
  const isMinor = state.modeId === 'aeolian';
  const scaleData = getScaleData(state.rootNote, state.scaleType === 'pentatonic' ? (isMinor ? 'pentatonic_minor' : 'pentatonic_major') : state.modeId);
  const scaleNotes = scaleData.notes;

  const randomStr = Math.floor(Math.random() * 6);
  const randomFret = Math.floor(Math.random() * 13);
  const fretNote = getFretNote(state.tuningId, randomStr, randomFret, scaleData);

  state.quizTargetString = randomStr;
  state.quizTargetFret = randomFret;
  state.quizTargetNote = fretNote.noteName;

  const tuning = TUNINGS[state.tuningId] || TUNINGS.standard;
  const strName = tuning.strings[randomStr]?.name || '';

  elements.quizPrompt.innerHTML = `What note is at <strong>String ${randomStr + 1} (${strName})</strong>, <strong>Fret ${randomFret === 0 ? 'Open' : randomFret}</strong>?`;

  const options = new Set([state.quizTargetNote]);
  while (options.size < 4) {
    const randNote = scaleNotes[Math.floor(Math.random() * scaleNotes.length)].name;
    options.add(randNote);
  }
  const shuffled = Array.from(options).sort(() => Math.random() - 0.5);

  elements.quizOptions.innerHTML = '';
  shuffled.forEach(opt => {
    const btn = document.createElement('button');
    btn.className = 'quiz-option-btn';
    btn.textContent = opt;
    btn.addEventListener('click', () => {
      state.quizTotal++;
      const isCorrect = opt === state.quizTargetNote;
      guitarAudio.playNote(fretNote.midi, 1.5, 0.85);

      if (isCorrect) {
        state.quizScore++;
        state.quizStreak++;
        btn.classList.add('correct');
      } else {
        state.quizStreak = 0;
        btn.classList.add('wrong');
        elements.quizOptions.querySelectorAll('.quiz-option-btn').forEach(b => {
          if (b.textContent === state.quizTargetNote) b.classList.add('correct');
        });
      }
      updateQuizStats();
      setTimeout(nextQuizQuestion, 1100);
    });
    elements.quizOptions.appendChild(btn);
  });
}

window.addEventListener('DOMContentLoaded', init);
