// Guitar Fretboard Theory Engine
// Provides full music theory computation for guitar scales, modes, CAGED boxes, intervals, and tunings.

export const NOTES_SHARP = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
export const NOTES_FLAT  = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];

// Preferred enharmonic spelling for common keys
export const KEY_SPELLINGS = {
  'C':  ['C', 'D', 'E', 'F', 'G', 'A', 'B'],
  'G':  ['G', 'A', 'B', 'C', 'D', 'E', 'F#'],
  'D':  ['D', 'E', 'F#', 'G', 'A', 'B', 'C#'],
  'A':  ['A', 'B', 'C#', 'D', 'E', 'F#', 'G#'],
  'E':  ['E', 'F#', 'G#', 'A', 'B', 'C#', 'D#'],
  'B':  ['B', 'C#', 'D#', 'E', 'F#', 'G#', 'A#'],
  'F#': ['F#', 'G#', 'A#', 'B', 'C#', 'D#', 'E#'],
  'F':  ['F', 'G', 'A', 'Bb', 'C', 'D', 'E'],
  'Bb': ['Bb', 'C', 'D', 'Eb', 'F', 'G', 'A'],
  'Eb': ['Eb', 'F', 'G', 'Ab', 'Bb', 'C', 'D'],
  'Ab': ['Ab', 'Bb', 'C', 'Db', 'Eb', 'F', 'G'],
  'Db': ['Db', 'Eb', 'F', 'Gb', 'Ab', 'Bb', 'C'],
};

export const ROOT_OPTIONS = [
  { value: 'C', label: 'C', alt: 'C' },
  { value: 'C#', label: 'C# / Db', alt: 'Db' },
  { value: 'D', label: 'D', alt: 'D' },
  { value: 'D#', label: 'D# / Eb', alt: 'Eb' },
  { value: 'E', label: 'E', alt: 'E' },
  { value: 'F', label: 'F', alt: 'F' },
  { value: 'F#', label: 'F# / Gb', alt: 'Gb' },
  { value: 'G', label: 'G', alt: 'G' },
  { value: 'G#', label: 'G# / Ab', alt: 'Ab' },
  { value: 'A', label: 'A', alt: 'A' },
  { value: 'A#', label: 'A# / Bb', alt: 'Bb' },
  { value: 'B', label: 'B', alt: 'B' },
];

export const SCALE_MODES = {
  ionian: {
    id: 'ionian',
    name: 'Major',
    fullName: 'Ionian (Major)',
    category: 'Major',
    intervals: [0, 2, 4, 5, 7, 9, 11],
    degrees: ['1', '2', '3', '4', '5', '6', '7'],
    degreeNames: ['Root', 'Major 2nd', 'Major 3rd', 'Perfect 4th', 'Perfect 5th', 'Major 6th', 'Major 7th'],
    // Pedagogy role: root = 'root', pentatonic tones (1,2,3,5,6) = 'pentatonic', modal tension (4,7) = 'modal'
    roles: ['root', 'pentatonic', 'pentatonic', 'modal', 'pentatonic', 'pentatonic', 'modal'],
    description: 'The standard Major scale. Bright, stable, foundational.'
  },
  aeolian: {
    id: 'aeolian',
    name: 'Minor',
    fullName: 'Aeolian (Natural Minor)',
    category: 'Minor',
    intervals: [0, 2, 3, 5, 7, 8, 10],
    degrees: ['1', '2', 'b3', '4', '5', 'b6', 'b7'],
    degreeNames: ['Root', 'Major 2nd', 'Minor 3rd', 'Perfect 4th', 'Perfect 5th', 'Minor 6th', 'Minor 7th'],
    // Pedagogy role: root = 'root', minor pentatonic (1,b3,4,5,b7) = 'pentatonic', modal tension (2,b6) = 'modal'
    roles: ['root', 'modal', 'pentatonic', 'pentatonic', 'pentatonic', 'modal', 'pentatonic'],
    description: 'The standard Natural Minor scale. Melancholic, emotional, epic.'
  },
  dorian: {
    id: 'dorian',
    name: 'Dorian',
    fullName: 'Dorian Mode',
    category: 'Minor',
    intervals: [0, 2, 3, 5, 7, 9, 10],
    degrees: ['1', '2', 'b3', '4', '5', '6', 'b7'],
    degreeNames: ['Root', 'Major 2nd', 'Minor 3rd', 'Perfect 4th', 'Perfect 5th', 'Major 6th', 'Minor 7th'],
    roles: ['root', 'pentatonic', 'pentatonic', 'pentatonic', 'pentatonic', 'modal', 'pentatonic'],
    description: 'Minor mode with a raised 6th. Smooth jazz, blues, funk.'
  },
  mixolydian: {
    id: 'mixolydian',
    name: 'Mixolydian',
    fullName: 'Mixolydian Mode',
    category: 'Major',
    intervals: [0, 2, 4, 5, 7, 9, 10],
    degrees: ['1', '2', '3', '4', '5', '6', 'b7'],
    degreeNames: ['Root', 'Major 2nd', 'Major 3rd', 'Perfect 4th', 'Perfect 5th', 'Major 6th', 'Minor 7th'],
    roles: ['root', 'pentatonic', 'pentatonic', 'modal', 'pentatonic', 'pentatonic', 'modal'],
    description: 'Dominant 7th major scale. Classic rock, blues, southern rock.'
  },
  pentatonic_major: {
    id: 'pentatonic_major',
    name: 'Major Pentatonic',
    fullName: 'Major Pentatonic',
    category: 'Pentatonic',
    intervals: [0, 2, 4, 7, 9],
    degrees: ['1', '2', '3', '5', '6'],
    degreeNames: ['Root', 'Major 2nd', 'Major 3rd', 'Perfect 5th', 'Major 6th'],
    roles: ['root', 'pentatonic', 'pentatonic', 'pentatonic', 'pentatonic'],
    description: '5-note sweet, melodic scale without harsh half-steps.'
  },
  pentatonic_minor: {
    id: 'pentatonic_minor',
    name: 'Minor Pentatonic',
    fullName: 'Minor Pentatonic',
    category: 'Pentatonic',
    intervals: [0, 3, 5, 7, 10],
    degrees: ['1', 'b3', '4', '5', 'b7'],
    degreeNames: ['Root', 'Minor 3rd', 'Perfect 4th', 'Perfect 5th', 'Minor 7th'],
    roles: ['root', 'pentatonic', 'pentatonic', 'pentatonic', 'pentatonic'],
    description: 'The cornerstone guitar solo scale for blues, rock, and metal.'
  }
};

export const CHORD_TYPES = {
  major: {
    id: 'major',
    name: 'Major Triad',
    intervals: [0, 4, 7],
    degrees: ['1', '3', '5'],
    degreeNames: ['Root', 'Major 3rd', 'Perfect 5th'],
    roles: ['root', 'pentatonic', 'pentatonic']
  },
  major7: {
    id: 'major7',
    name: 'Major 7th',
    intervals: [0, 4, 7, 11],
    degrees: ['1', '3', '5', '7'],
    degreeNames: ['Root', 'Major 3rd', 'Perfect 5th', 'Major 7th'],
    roles: ['root', 'pentatonic', 'pentatonic', 'modal']
  },
  minor: {
    id: 'minor',
    name: 'Minor Triad',
    intervals: [0, 3, 7],
    degrees: ['1', 'b3', '5'],
    degreeNames: ['Root', 'Minor 3rd', 'Perfect 5th'],
    roles: ['root', 'pentatonic', 'pentatonic']
  },
  minor7: {
    id: 'minor7',
    name: 'Minor 7th',
    intervals: [0, 3, 7, 10],
    degrees: ['1', 'b3', '5', 'b7'],
    degreeNames: ['Root', 'Minor 3rd', 'Perfect 5th', 'Minor 7th'],
    roles: ['root', 'pentatonic', 'pentatonic', 'pentatonic']
  }
};

export const TUNINGS = {
  standard: {
    id: 'standard',
    name: 'Standard (E A D G B E)',
    strings: [
      { name: 'e', midi: 64, semitone: 4, octave: 4 }, // E4
      { name: 'B', midi: 59, semitone: 11, octave: 3 }, // B3
      { name: 'G', midi: 55, semitone: 7, octave: 3 }, // G3
      { name: 'D', midi: 50, semitone: 2, octave: 3 }, // D3
      { name: 'A', midi: 45, semitone: 9, octave: 2 }, // A2
      { name: 'E', midi: 40, semitone: 4, octave: 2 }, // E2
    ]
  },
  drop_d: {
    id: 'drop_d',
    name: 'Drop D (D A D G B E)',
    strings: [
      { name: 'e', midi: 64, semitone: 4, octave: 4 },
      { name: 'B', midi: 59, semitone: 11, octave: 3 },
      { name: 'G', midi: 55, semitone: 7, octave: 3 },
      { name: 'D', midi: 50, semitone: 2, octave: 3 },
      { name: 'A', midi: 45, semitone: 9, octave: 2 },
      { name: 'D', midi: 38, semitone: 2, octave: 2 },
    ]
  },
  half_step_down: {
    id: 'half_step_down',
    name: 'Eb Standard (Eb Ab Db Gb Bb Eb)',
    strings: [
      { name: 'eb', midi: 63, semitone: 3, octave: 4 },
      { name: 'Bb', midi: 58, semitone: 10, octave: 3 },
      { name: 'Gb', midi: 54, semitone: 6, octave: 3 },
      { name: 'Db', midi: 49, semitone: 1, octave: 3 },
      { name: 'Ab', midi: 44, semitone: 8, octave: 2 },
      { name: 'Eb', midi: 39, semitone: 3, octave: 2 },
    ]
  }
};

export function noteToSemitone(noteName) {
  if (!noteName) return 0;
  const clean = noteName.trim().toUpperCase();
  let idx = NOTES_SHARP.findIndex(n => n.toUpperCase() === clean);
  if (idx !== -1) return idx;
  idx = NOTES_FLAT.findIndex(n => n.toUpperCase() === clean);
  if (idx !== -1) return idx;
  return 0;
}

export function semitoneToNoteName(semitone, rootNote = 'C', preferFlats = false) {
  const norm = ((semitone % 12) + 12) % 12;
  const spelling = KEY_SPELLINGS[rootNote];
  if (spelling) {
    for (const n of spelling) {
      if (noteToSemitone(n) === norm) return n;
    }
  }
  return preferFlats ? NOTES_FLAT[norm] : NOTES_SHARP[norm];
}

export function getScaleData(rootNote = 'C', modeId = 'ionian') {
  const mode = SCALE_MODES[modeId] || SCALE_MODES.ionian;
  const rootSemi = noteToSemitone(rootNote);
  const preferFlats = ['F', 'Bb', 'Eb', 'Ab', 'Db'].includes(rootNote) || rootNote.includes('b');

  const notes = mode.intervals.map((interval, i) => {
    const semi = (rootSemi + interval) % 12;
    const name = semitoneToNoteName(semi, rootNote, preferFlats);
    const degree = mode.degrees[i];
    const degreeName = mode.degreeNames[i];
    const role = mode.roles[i];
    return {
      semitone: semi,
      name,
      interval,
      degree,
      degreeName,
      role,
      isRoot: interval === 0
    };
  });

  return {
    rootNote,
    modeId,
    modeName: mode.name,
    fullName: mode.fullName,
    category: mode.category,
    description: mode.description,
    notes,
    noteSemitones: new Set(notes.map(n => n.semitone)),
    noteMap: new Map(notes.map(n => [n.semitone, n]))
  };
}

export function getChordData(rootNote = 'C', modeId = 'ionian') {
  const isMinor = modeId === 'aeolian' || modeId === 'dorian' || modeId === 'pentatonic_minor';
  const chordDef = isMinor ? CHORD_TYPES.minor7 : CHORD_TYPES.major7;
  const rootSemi = noteToSemitone(rootNote);
  const preferFlats = ['F', 'Bb', 'Eb', 'Ab', 'Db'].includes(rootNote) || rootNote.includes('b');

  const notes = chordDef.intervals.map((interval, i) => {
    const semi = (rootSemi + interval) % 12;
    const name = semitoneToNoteName(semi, rootNote, preferFlats);
    const degree = chordDef.degrees[i];
    const degreeName = chordDef.degreeNames[i];
    const role = chordDef.roles[i];
    return {
      semitone: semi,
      name,
      interval,
      degree,
      degreeName,
      role,
      isRoot: interval === 0
    };
  });

  return {
    rootNote,
    chordName: `${rootNote} ${chordDef.name}`,
    notes,
    noteSemitones: new Set(notes.map(n => n.semitone)),
    noteMap: new Map(notes.map(n => [n.semitone, n]))
  };
}

/**
 * Computes CAGED Box Positions for 22 frets
 */
export function getBoxPositions(rootNote = 'C', modeId = 'ionian') {
  const rootSemi = noteToSemitone(rootNote);
  const rootOnString6 = (rootSemi - 4 + 12) % 12;

  let boxes = [];

  if (modeId === 'ionian' || modeId === 'mixolydian' || modeId === 'pentatonic_major') {
    // 5 CAGED Positions relative to root:
    // Box 1 (E-Shape): Root on 6th string
    // Box 2 (D-Shape)
    // Box 3 (C-Shape)
    // Box 4 (A-Shape): Root on 5th string
    // Box 5 (G-Shape)
    const base = rootOnString6;
    boxes = [
      { id: 'box1', name: 'Box 1 (E-Shape)', center: base, minSpan: -1, maxSpan: 3 },
      { id: 'box2', name: 'Box 2 (D-Shape)', center: base + 2, minSpan: 0, maxSpan: 3 },
      { id: 'box3', name: 'Box 3 (C-Shape)', center: base + 5, minSpan: -1, maxSpan: 3 },
      { id: 'box4', name: 'Box 4 (A-Shape)', center: base + 7, minSpan: 0, maxSpan: 3 },
      { id: 'box5', name: 'Box 5 (G-Shape)', center: base + 10, minSpan: -1, maxSpan: 3 },
    ];
  } else {
    // Aeolian / Minor
    const base = rootOnString6;
    boxes = [
      { id: 'box1', name: 'Box 1 (Minor E-Shape)', center: base, minSpan: 0, maxSpan: 3 },
      { id: 'box2', name: 'Box 2 (Minor D-Shape)', center: base + 3, minSpan: -1, maxSpan: 3 },
      { id: 'box3', name: 'Box 3 (Minor C-Shape)', center: base + 5, minSpan: 0, maxSpan: 3 },
      { id: 'box4', name: 'Box 4 (Minor A-Shape)', center: base + 7, minSpan: 0, maxSpan: 4 },
      { id: 'box5', name: 'Box 5 (Minor G-Shape)', center: base + 10, minSpan: 0, maxSpan: 3 },
    ];
  }

  return boxes.map(b => {
    // Normalize primary range into [0..12] or closest positive frets
    let normCenter = ((b.center % 12) + 12) % 12;
    let primeMin = normCenter + b.minSpan;
    let primeMax = normCenter + b.maxSpan;
    if (primeMin < 0) {
      primeMin += 12;
      primeMax += 12;
    }

    const ranges = [];
    for (let offset = -12; offset <= 24; offset += 12) {
      const minF = primeMin + offset;
      const maxF = primeMax + offset;
      if (maxF >= 0 && minF <= 22) {
        ranges.push({
          startFret: Math.max(0, minF),
          endFret: Math.min(22, maxF)
        });
      }
    }

    // Sort ranges so lowest active fret range is first
    ranges.sort((r1, r2) => r1.startFret - r2.startFret);

    return {
      id: b.id,
      name: b.name,
      primaryRange: { startFret: primeMin, endFret: primeMax },
      ranges,
      containsFret: (fret) => ranges.some(r => fret >= r.startFret && fret <= r.endFret)
    };
  });
}

export function getFretNote(tuningId, stringIndex, fret, scaleData, activeBoxId = 'all', boxList = []) {
  const tuning = TUNINGS[tuningId] || TUNINGS.standard;
  const stringInfo = tuning.strings[stringIndex];
  if (!stringInfo) return null;

  const midi = stringInfo.midi + fret;
  const semitone = (stringInfo.semitone + fret) % 12;
  const octave = Math.floor(midi / 12) - 1;

  const scaleNote = scaleData.noteMap.get(semitone);
  const isInScale = !!scaleNote;

  let isInBox = true;
  if (activeBoxId !== 'all') {
    const box = boxList.find(b => b.id === activeBoxId);
    isInBox = box ? box.containsFret(fret) : true;
  }

  const noteName = scaleNote 
    ? scaleNote.name 
    : semitoneToNoteName(semitone, scaleData.rootNote);

  return {
    stringIndex,
    fret,
    midi,
    semitone,
    octave,
    noteName,
    fullPitch: `${noteName}${octave}`,
    isInScale,
    isInBox,
    isRoot: scaleNote ? scaleNote.isRoot : false,
    degree: scaleNote ? scaleNote.degree : null,
    degreeName: scaleNote ? scaleNote.degreeName : null,
    role: scaleNote ? scaleNote.role : 'none',
    interval: scaleNote ? scaleNote.interval : null
  };
}

/**
 * Computes localized 4-5 fret box diagram data
 * Given a root note, mode, scaleType ('pentatonic' or 'full'), and boxId or startFret.
 */
export function get4to5FretBoxData(rootNote = 'C', modeId = 'ionian', scaleType = 'pentatonic', boxId = 'box1', customStartFret = null) {
  const isMinor = modeId === 'aeolian' || modeId === 'dorian' || modeId === 'pentatonic_minor';
  
  // Decide effective mode definition
  let effectiveModeId = modeId;
  if (scaleType === 'pentatonic') {
    effectiveModeId = isMinor ? 'pentatonic_minor' : 'pentatonic_major';
  } else {
    effectiveModeId = isMinor ? 'aeolian' : 'ionian';
  }

  const scaleData = getScaleData(rootNote, effectiveModeId);
  const rootSemi = noteToSemitone(rootNote);
  const rootOnString6 = (rootSemi - 4 + 12) % 12;

  let startFret = 0;
  let fretSpan = 4; // Default 4 frets wide (e.g. frets 5..8)

  if (customStartFret !== null && customStartFret !== undefined) {
    startFret = Math.max(0, Math.min(18, customStartFret));
  } else {
    // Standard CAGED box start fret calculation
    if (isMinor) {
      switch (boxId) {
        case 'box1': startFret = rootOnString6; fretSpan = 4; break;
        case 'box2': startFret = (rootOnString6 + 2) % 12; fretSpan = 4; break;
        case 'box3': startFret = (rootOnString6 + 5) % 12; fretSpan = 4; break;
        case 'box4': startFret = (rootOnString6 + 7) % 12; fretSpan = 4; break;
        case 'box5': startFret = (rootOnString6 + 10) % 12; fretSpan = 4; break;
        default: startFret = rootOnString6; fretSpan = 4;
      }
    } else {
      switch (boxId) {
        case 'box1': startFret = (rootOnString6 - 1 + 12) % 12; fretSpan = 4; break;
        case 'box2': startFret = (rootOnString6 + 2) % 12; fretSpan = 4; break;
        case 'box3': startFret = (rootOnString6 + 4) % 12; fretSpan = 4; break;
        case 'box4': startFret = (rootOnString6 + 7) % 12; fretSpan = 4; break;
        case 'box5': startFret = (rootOnString6 + 9) % 12; fretSpan = 4; break;
        default: startFret = (rootOnString6 - 1 + 12) % 12; fretSpan = 4;
      }
    }
  }

  const endFret = startFret + fretSpan - 1;
  const frets = [];
  for (let f = startFret; f <= endFret; f++) {
    frets.push(f);
  }

  // Build grid of notes: String 0 (high e) to String 5 (low E)
  const tuning = TUNINGS.standard;
  const stringsGrid = [];

  for (let strIdx = 0; strIdx < 6; strIdx++) {
    const stringInfo = tuning.strings[strIdx];
    const fretNotes = [];

    for (let fIdx = 0; fIdx < frets.length; fIdx++) {
      const fret = frets[fIdx];
      const midi = stringInfo.midi + fret;
      const semitone = (stringInfo.semitone + fret) % 12;
      const octave = Math.floor(midi / 12) - 1;

      const scaleNote = scaleData.noteMap.get(semitone);
      const isInScale = !!scaleNote;
      const isRoot = scaleNote ? scaleNote.isRoot : false;
      const noteName = scaleNote ? scaleNote.name : semitoneToNoteName(semitone, rootNote);

      fretNotes.push({
        stringIndex: strIdx,
        stringName: stringInfo.name,
        fret,
        relFret: fIdx, // 0 to 3 or 4
        midi,
        semitone,
        octave,
        noteName,
        isRoot,
        isInScale,
        degree: scaleNote ? scaleNote.degree : null,
        degreeName: scaleNote ? scaleNote.degreeName : null,
        role: scaleNote ? scaleNote.role : 'none'
      });
    }

    stringsGrid.push(fretNotes);
  }

  return {
    rootNote,
    modeId: effectiveModeId,
    modeName: scaleData.modeName,
    scaleType,
    boxId,
    startFret,
    endFret,
    fretSpan,
    frets,
    stringsGrid,
    scaleData
  };
}
